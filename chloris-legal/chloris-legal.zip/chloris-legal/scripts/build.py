#!/usr/bin/env python3
"""Build static HTML pages from markdown legal documents.
   Each page uses the shared Chloris editorial template."""

import markdown
import os
from pathlib import Path

ROOT = Path(__file__).parent.parent  # /home/claude/chloris-legal
SITE = ROOT / "site"

# Page configurations: (md_filename, html_filename, page_title, lang, back_label)
PAGES = [
    ("terms-en.md",   "terms-en.html",   "Terms of Use",        "en", "Back"),
    ("terms-tr.md",   "terms-tr.html",   "Kullanım Koşulları",  "tr", "Geri"),
    ("privacy-en.md", "privacy-en.html", "Privacy Policy",      "en", "Back"),
    ("privacy-tr.md", "privacy-tr.html", "Gizlilik Politikası", "tr", "Geri"),
]

TEMPLATE = """<!DOCTYPE html>
<html lang="{lang}">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} — Chloris</title>
<meta name="description" content="{title} for Chloris: Plant Scan & Garden.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,600;1,9..144,400&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  :root {{
    --bg: #f7f5f0;
    --bg-warm: #ede8dc;
    --ink: #1a2419;
    --ink-soft: #4a5648;
    --leaf: #4a6741;
    --leaf-deep: #2d4226;
    --accent: #c9a961;
    --line: rgba(26, 36, 25, 0.12);
    --line-soft: rgba(26, 36, 25, 0.06);
  }}

  * {{ margin: 0; padding: 0; box-sizing: border-box; }}

  html {{ scroll-behavior: smooth; }}

  body {{
    background: var(--bg);
    color: var(--ink);
    font-family: 'Inter', -apple-system, sans-serif;
    font-size: 16px;
    line-height: 1.7;
    background-image:
      radial-gradient(circle at 100% 0%, rgba(74, 103, 65, 0.04) 0%, transparent 30%),
      radial-gradient(circle at 0% 100%, rgba(201, 169, 97, 0.04) 0%, transparent 30%);
  }}

  .container {{
    max-width: 720px;
    margin: 0 auto;
    padding: 48px 32px 96px;
  }}

  .topbar {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 32px;
    border-bottom: 1px solid var(--line);
    margin-bottom: 56px;
  }}

  .back {{
    display: inline-flex;
    align-items: center;
    gap: 10px;
    color: var(--ink-soft);
    text-decoration: none;
    font-size: 14px;
    transition: color 0.3s, gap 0.3s;
  }}

  .back:hover {{
    color: var(--leaf);
    gap: 14px;
  }}

  .back-arrow {{
    font-family: 'Fraunces', serif;
    font-size: 18px;
  }}

  .brand {{
    display: flex;
    align-items: center;
    gap: 10px;
  }}

  .brand-mark {{
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--leaf) 0%, var(--leaf-deep) 100%);
    display: grid;
    place-items: center;
    color: white;
    font-family: 'Fraunces', serif;
    font-weight: 600;
    font-size: 16px;
    font-style: italic;
  }}

  .brand-name {{
    font-family: 'Fraunces', serif;
    font-size: 18px;
    font-style: italic;
    color: var(--leaf);
  }}

  /* MARKDOWN CONTENT STYLES */
  .doc h1 {{
    font-family: 'Fraunces', serif;
    font-size: clamp(36px, 5vw, 52px);
    font-weight: 300;
    line-height: 1.1;
    letter-spacing: -0.02em;
    margin-bottom: 24px;
    color: var(--ink);
  }}

  .doc h2 {{
    font-family: 'Fraunces', serif;
    font-size: 26px;
    font-weight: 400;
    line-height: 1.25;
    letter-spacing: -0.01em;
    margin-top: 56px;
    margin-bottom: 20px;
    padding-top: 24px;
    border-top: 1px solid var(--line-soft);
    color: var(--leaf-deep);
  }}

  .doc h2:first-of-type {{
    border-top: none;
    padding-top: 0;
    margin-top: 48px;
  }}

  .doc h3 {{
    font-family: 'Fraunces', serif;
    font-size: 20px;
    font-weight: 600;
    margin-top: 32px;
    margin-bottom: 12px;
    color: var(--ink);
    letter-spacing: -0.005em;
  }}

  .doc p {{
    margin-bottom: 18px;
    color: var(--ink);
  }}

  .doc strong {{
    font-weight: 600;
    color: var(--ink);
  }}

  .doc em {{
    font-style: italic;
  }}

  .doc a {{
    color: var(--leaf);
    text-decoration: none;
    border-bottom: 1px solid rgba(74, 103, 65, 0.3);
    transition: border-color 0.2s, color 0.2s;
    word-break: break-word;
  }}

  .doc a:hover {{
    color: var(--leaf-deep);
    border-bottom-color: var(--leaf);
  }}

  .doc ul, .doc ol {{
    margin-bottom: 20px;
    padding-left: 24px;
  }}

  .doc li {{
    margin-bottom: 8px;
    color: var(--ink);
  }}

  .doc ul li::marker {{
    color: var(--accent);
  }}

  .doc table {{
    width: 100%;
    border-collapse: collapse;
    margin: 24px 0;
    font-size: 14px;
    background: rgba(237, 232, 220, 0.4);
    border-radius: 6px;
    overflow: hidden;
  }}

  .doc th {{
    background: var(--leaf);
    color: white;
    padding: 12px 14px;
    text-align: left;
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.02em;
  }}

  .doc td {{
    padding: 12px 14px;
    border-bottom: 1px solid var(--line-soft);
    color: var(--ink);
  }}

  .doc tr:last-child td {{
    border-bottom: none;
  }}

  .doc hr {{
    border: none;
    height: 1px;
    background: linear-gradient(90deg, transparent, var(--line), transparent);
    margin: 56px 0;
  }}

  /* First paragraph (effective date / last updated) treatment */
  .doc > p:first-of-type {{
    font-size: 14px;
    color: var(--ink-soft);
    padding: 16px 20px;
    background: var(--bg-warm);
    border-left: 3px solid var(--accent);
    border-radius: 0 4px 4px 0;
    margin-bottom: 32px;
  }}

  /* Italics-only final blockquote-style paragraph */
  .doc > p:last-child > em:only-child {{
    display: block;
    margin-top: 56px;
    padding-top: 32px;
    border-top: 1px solid var(--line);
    font-size: 15px;
    color: var(--ink-soft);
    text-align: center;
  }}

  @media (max-width: 600px) {{
    .container {{ padding: 32px 20px 64px; }}
    .topbar {{ margin-bottom: 40px; padding-bottom: 24px; }}
    .doc h1 {{ font-size: 32px; }}
    .doc h2 {{ font-size: 22px; margin-top: 40px; }}
    .doc h3 {{ font-size: 17px; margin-top: 24px; }}
    .doc p, .doc li {{ font-size: 15px; }}
    .doc table {{ font-size: 13px; }}
    .doc th, .doc td {{ padding: 10px; }}
    .doc > p:first-of-type {{ padding: 12px 16px; }}
  }}

  @keyframes fadeUp {{
    from {{ opacity: 0; transform: translateY(8px); }}
    to {{ opacity: 1; transform: translateY(0); }}
  }}

  .topbar, .doc {{ animation: fadeUp 0.6s cubic-bezier(0.2, 0.8, 0.2, 1) backwards; }}
  .doc {{ animation-delay: 0.1s; }}

  /* Print-friendly */
  @media print {{
    body {{ background: white; }}
    .topbar {{ border-bottom: 1px solid #999; }}
    .doc h2 {{ break-after: avoid; }}
    .doc table {{ break-inside: avoid; }}
  }}
</style>
</head>
<body>

<div class="container">

  <header class="topbar">
    <a class="back" href="index.html">
      <span class="back-arrow">←</span>
      <span>{back_label}</span>
    </a>
    <div class="brand">
      <div class="brand-mark">C</div>
      <span class="brand-name">Chloris</span>
    </div>
  </header>

  <article class="doc">
    {content}
  </article>

</div>

</body>
</html>
"""

def build():
    SITE.mkdir(exist_ok=True)
    md = markdown.Markdown(extensions=['extra', 'tables', 'sane_lists'])

    for md_file, html_file, title, lang, back_label in PAGES:
        src = ROOT / md_file
        if not src.exists():
            print(f"  ✗ missing: {md_file}")
            continue

        text = src.read_text(encoding='utf-8')
        html_content = md.convert(text)
        md.reset()

        page = TEMPLATE.format(
            lang=lang,
            title=title,
            back_label=back_label,
            content=html_content,
        )

        out = SITE / html_file
        out.write_text(page, encoding='utf-8')
        size_kb = len(page) / 1024
        print(f"  ✓ {html_file}  ({size_kb:.1f} KB)")

    print(f"\nDone. Site at: {SITE}")

if __name__ == "__main__":
    build()
