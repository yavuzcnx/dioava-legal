# Chloris — Legal Site

Chloris uygulamasının **Terms of Use** ve **Privacy Policy** dokümanlarını host eden statik site. GitHub Pages üzerinde ücretsiz yayınlanır, App Store / Google Play submission'larında kullanılır.

## İçerik

```
chloris-legal/
├── README.md                    ← bu dosya (deploy rehberi)
├── terms-en.md                  ← İngilizce kullanım koşulları (kaynak)
├── terms-tr.md                  ← Türkçe kullanım koşulları (kaynak)
├── privacy-en.md                ← İngilizce gizlilik politikası (kaynak)
├── privacy-tr.md                ← Türkçe gizlilik politikası (kaynak)
├── scripts/
│   └── build.py                 ← markdown → HTML build script
└── site/                        ← BURASI YAYINLANIR
    ├── index.html               ← landing page (4 dokümana link)
    ├── 404.html                 ← bulunamayan sayfa
    ├── terms-en.html
    ├── terms-tr.html
    ├── privacy-en.html
    ├── privacy-tr.html
    └── .nojekyll                ← GitHub Pages için (Jekyll'i kapat)
```

## Yayınlama (GitHub Pages)

### 1) GitHub'da repo oluştur

1. https://github.com/new adresine git
2. Repository name: **`chloris-legal`** (veya istediğin bir ad)
3. **Public** seç (GitHub Pages free tier için public şart, private istersen GitHub Pro lazım)
4. README ekleme, .gitignore ekleme — bunları biz hazırlıyoruz
5. **Create repository**

### 2) Local'de git başlat ve push'la

Bilgisayarında bu klasörün olduğu dizinde terminal aç:

```bash
cd /path/to/chloris-legal

git init
git add .
git commit -m "Initial legal site"
git branch -M main
git remote add origin https://github.com/<KULLANICI_ADIN>/chloris-legal.git
git push -u origin main
```

> Eğer SSH key kuruluysa `git@github.com:<KULLANICI_ADIN>/chloris-legal.git` formatını kullan.

### 3) GitHub Pages'i aktive et

1. Repo sayfasında üstten **Settings** → sol menü **Pages**
2. **Source** altında: **Deploy from a branch** seç
3. **Branch:** `main`
4. **Folder:** `/site` seç (önemli! Markdown dosyaları root'ta, HTML site/ içinde)
5. **Save** tıkla

1-2 dakika sonra sayfanın tepesinde şu URL çıkar:

```
https://<KULLANICI_ADIN>.github.io/chloris-legal/
```

Bu URL Apple ve Google'a vereceğin URL'lerin **base'i** olacak.

### 4) Apple / Google'a verilecek URL'ler

App Store Connect ve Play Console'da şu alanları doldururken bu URL'leri kullan:

| Alan | URL |
|------|-----|
| **App Information → Privacy Policy URL** | `https://<KULL>.github.io/chloris-legal/privacy-en.html` |
| **App Information → Terms of Use URL** | `https://<KULL>.github.io/chloris-legal/terms-en.html` |
| **In-app paywall — Privacy linki** | `https://<KULL>.github.io/chloris-legal/privacy-en.html` |
| **In-app paywall — Terms linki** | `https://<KULL>.github.io/chloris-legal/terms-en.html` |
| **Türkiye localization Privacy** | `https://<KULL>.github.io/chloris-legal/privacy-tr.html` |
| **Türkiye localization Terms** | `https://<KULL>.github.io/chloris-legal/terms-tr.html` |

> Apple **bir adet** Privacy Policy URL ister; oraya İngilizce versiyonu ver. App içi paywall'da kullanıcının diline göre TR veya EN versiyonu açabilirsin.

## Custom Domain (opsiyonel — `legal.chloris.app` gibi)

Eğer `chloris.app` veya benzeri bir domain'in varsa:

1. Domain DNS panelinde CNAME kaydı: `legal` → `<KULL>.github.io`
2. Repo'da `site/` klasörüne `CNAME` adında bir dosya oluştur, içine yaz: `legal.chloris.app`
3. GitHub Settings → Pages → **Custom domain** alanına `legal.chloris.app` yaz, **Save**
4. **Enforce HTTPS** seçeneğini işaretle (24 saat sonra otomatik aktif olur)

Sonra Apple/Google'a verdiğin URL'ler şöyle olur:
```
https://legal.chloris.app/privacy-en.html
https://legal.chloris.app/terms-en.html
```

Daha profesyonel, daha güvenilir görünür. Apple reviewer "github.io" subdomain'ini görmemiş olur.

## Güncelleme yapma

Markdown dosyalarını değiştirdikten sonra:

```bash
cd chloris-legal
python3 scripts/build.py    # site/ içindeki HTML'leri yeniden build eder
git add -A
git commit -m "Update legal docs YYYY-MM-DD"
git push
```

GitHub Pages 1-2 dakika içinde otomatik deploy eder.

## E-posta Adresleri

Dokümanlarda geçen e-postalar:

- **diova@diova.app** — genel destek, hesap silme talepleri
- **diova@diova.app** — KVKK / GDPR talepleri

Bu adresleri **kurma**! En kolay yol:

- **Domain'in varsa** (chloris.app, diova.app vb.): domain provider'ında email forwarding kur (genelde ücretsiz). `support@` ve `privacy@` adreslerini kendi gerçek mailine (örn. resul.sari@gmail.com) yönlendir.
- **Domain'in yoksa**: README'de bu adresleri kendi gerçek email'inle değiştir, dokümanları yeniden build et. Apple kişisel email adresine de izin verir, ama profesyonel görünmez.

## Önemli Notlar

⚠️ **Bu dokümanlar yasal tavsiye değildir.** Resul Sarı'nın özel durumuna göre genel-amaçlı bir şablondan üretilmiştir. Türkiye'de büyük gelir hedefliyor veya AB'de aktif satış yapacaksan, **bir avukatla bunları gözden geçirmeni öneririm** (özellikle KVKK aydınlatma metni ve GDPR DPA tarafı).

⚠️ **E-posta adresleri çalışmıyorsa Apple reject eder.** Reviewer Privacy Policy'deki email'e mail atıp dönüş bekliyor. Yayınlamadan önce e-postaları çalışır hâle getir.

⚠️ **Domain bağlamadan da Apple kabul ediyor.** `<kull>.github.io/chloris-legal/...` URL'leri ile launch edebilirsin, sonra `legal.chloris.app` gibi custom domain'e geçersin (URL'leri App Store Connect'te güncellersin).
