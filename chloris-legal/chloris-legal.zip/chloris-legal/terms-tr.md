# Kullanım Koşulları

**Son güncelleme:** 7 Mayıs 2026
**Yürürlük tarihi:** 7 Mayıs 2026

Bu Kullanım Koşulları ("Koşullar"), Türkiye'de **Diova** ticari adıyla faaliyet gösteren şahıs şirketi **Resul Sarı** ("biz", "bize", "tarafımız") tarafından sunulan **Chloris: Plant Scan & Garden** mobil uygulamasının ("Uygulama") kullanımına ilişkin sizinle ("Kullanıcı", "siz") aramızdaki yasal sözleşmeyi düzenler. Uygulamayı indirerek, kurarak veya kullanarak bu Koşullar'a tabi olmayı kabul etmiş sayılırsınız. Kabul etmiyorsanız Uygulamayı kullanmayınız.

---

## 1. Koşulların Kabulü

Hesap oluşturarak veya Uygulamayı kullanarak en az **13 yaşında** olduğunuzu (veya bulunduğunuz ülkede veri işleme onayı için gereken minimum yaşta olduğunuzu) ve bağlayıcı bir sözleşme akdetme ehliyetine sahip olduğunuzu beyan edersiniz. Bir tüzel kişilik adına kullanıyorsanız, o tüzel kişiliği bağlama yetkisine sahip olduğunuzu beyan edersiniz.

## 2. Lisans

Bu Koşullara uymanız şartıyla, size Uygulamayı sahip olduğunuz veya kontrol ettiğiniz cihazlara indirme ve yalnızca **kişisel, ticari olmayan amaçlarla** kullanma hakkı veren **sınırlı, münhasır olmayan, devredilemez ve geri alınabilir bir lisans** veriyoruz. Bu lisans, iOS kullanıcıları için Apple Inc., Android kullanıcıları için Google LLC tarafından kendi şartları çerçevesinde sağlanır.

## 3. Abonelikler ve Uygulama İçi Satın Alımlar

### 3.1. Mevcut Planlar

- **Chloris Pro Aylık** — otomatik yenilenen abonelik, aylık ücretlendirme
- **Chloris Pro Yıllık** — otomatik yenilenen abonelik, yıllık ücretlendirme
- **Chloris Pro Ömür Boyu** — tek seferlik ödeme, sınırsız erişim

Fiyatlar, satın alma anında Uygulama içinde yerel para biriminizde gösterilir.

### 3.2. Otomatik Yenileme

Otomatik yenilenen abonelikler, **mevcut dönemin bitiminden en az 24 saat önce iptal edilmediği takdirde**, her fatura döneminin sonunda otomatik olarak yenilenir. Ödeme yönteminiz, mevcut dönemin bitmesinden önceki 24 saat içinde yenileme tutarıyla ücretlendirilir.

Aboneliklerinizi istediğiniz zaman:

- **iOS:** App Store hesap ayarlarından
- **Android:** Google Play hesap ayarlarından

yönetebilir ve iptal edebilirsiniz. İptal, mevcut fatura döneminin sonunda yürürlüğe girer; kullanılmayan dönem için kısmi iade yapılmaz.

### 3.3. Ücretsiz Deneme (sunulduğu durumlarda)

Ücretsiz deneme sunuluyorsa, deneme süresi sona ermeden **en az 24 saat önce iptal edilmediği takdirde**, deneme süresinin sonunda otomatik olarak ücretli aboneliğe dönüşür. Her Apple Kimliği veya Google hesabı için yalnızca **bir** ücretsiz deneme hakkı tanınır.

### 3.4. İade Politikası

Tüm satın alımlar Apple veya Google tarafından işleme alınır ve bu platformların iade politikalarına tabidir:

- **iOS / App Store:** [https://support.apple.com/tr-tr/HT204084](https://support.apple.com/tr-tr/HT204084)
- **Android / Google Play:** [https://support.google.com/googleplay/answer/2479637](https://support.google.com/googleplay/answer/2479637)

İadeleri doğrudan biz işleme alamayız. **Tüketicinin Korunması Hakkında Kanun** kapsamındaki cayma hakkınız mahfuzdur. Ömür boyu satın alımlar, yürürlükteki yasaların gerektirdiği durumlar haricinde iade edilemez.

### 3.5. Satın Alımları Geri Yükleme

Önceki satın alımlarınızı, Uygulama içindeki **"Satın Almaları Geri Yükle"** seçeneğine dokunarak geri yükleyebilirsiniz; ancak bunun için orijinal satın alma için kullanılan Apple Kimliği veya Google hesabıyla oturum açmış olmanız gerekir.

## 4. Kullanıcı Hesabı

Belirli özelliklere erişmek için geçerli bir e-posta adresi ile hesap oluşturmanız gerekir. Şunlardan siz sorumlusunuz:

- Giriş bilgilerinizin gizliliğini korumak
- Hesabınız altında gerçekleştirilen tüm faaliyetler
- Yetkisiz erişim durumunda derhâl **diova@diova.app** adresine bildirim yapmak

Bu Koşulları ihlal eden hesapları askıya alma veya sonlandırma hakkımızı saklı tutarız.

## 5. Kabul Edilebilir Kullanım

Aşağıdakileri yapmamayı kabul edersiniz:

- Uygulamanın tersine mühendisliğini yapmak, kaynak koduna dönüştürmek veya parçalarına ayırmak
- Uygulamayı yasalara aykırı veya yasal olmayan bir amaçla kullanmak
- Saldırgan, hak ihlali yaratan veya zararlı içerik yüklemek
- Güvenlik veya abonelik mekanizmalarını atlatmaya çalışmak
- Otomatik sistemler (bot, scraper) ile Uygulamaya erişmek
- Uygulamayı veya içeriğini yeniden satmak, alt lisans vermek veya ticari olarak istismar etmek

İhlaller, geri ödeme yapılmaksızın hesabın derhâl sonlandırılmasına yol açabilir.

## 6. Kullanıcı Tarafından Oluşturulan İçerik

Bitki fotoğraflarınızı, notlarınızı veya diğer içeriklerinizi koleksiyonunuza yüklerseniz ("Kullanıcı İçeriği"), bu içeriklerin sahipliği size aittir. Yüklemekle, yalnızca Hizmeti sağlamak amacıyla içeriği saklamak, görüntülemek ve işlemek için bize **dünya çapında, telifsiz, münhasır olmayan bir lisans** vermiş olursunuz. Kullanıcı İçeriğiniz üzerinde herhangi bir mülkiyet iddiamız yoktur ve **açık rızanız olmadan** içeriğinizi pazarlama için kullanmayız.

## 7. Bitki Tanımlama — Garanti Yoktur

Uygulama, fotoğraflardan bitkileri tanımlamak için yapay zekâ kullanır. **Tanımlamalar tahminîdir ve hatalı olabilir.** Uygulamaya şu konularda **güvenmeyin**:

- Zehirli, toksik veya yenilebilir bitkilerin tanımlanması
- Sağlık veya güvenlik içeren tıbbi, tarımsal veya bahçecilik kararları
- Korunan veya nesli tükenmekte olan türlerin yasal sınıflandırması

Uygulama tanımlamalarına dayanarak herhangi bir bitkiyi tüketmeden, ele almadan veya tedavi etmeden önce **mutlaka uzman bir kişiye danışın**. Tanımlamalara güvenmekten kaynaklanan zararlardan sorumlu değiliz.

## 8. Fikri Mülkiyet

Uygulama; tasarımı, kodu, grafikleri, metni ve markaları (topluca "Materyaller") dâhil olmak üzere **Resul Sarı'ya veya lisans verenlere aittir** ve telif hakkı ile diğer fikri mülkiyet yasalarıyla korunmaktadır. Madde 2'deki sınırlı lisans dışında size hiçbir hak tanınmamaktadır.

## 9. Üçüncü Taraf Hizmetleri

Uygulama aşağıdaki üçüncü taraf hizmetlerini entegre eder:

- **Apple App Store / Google Play** — ödeme işlemleri
- **Supabase** — kimlik doğrulama ve veri depolama
- **AdMob (Google)** — ücretsiz katman kullanıcıları için reklam
- **Yapay zekâ bitki tanıma servisleri** — görüntü analizi

Üçüncü taraf hizmetlerinin kullanımı kendi şartlarına tabidir. Üçüncü tarafların uygulamalarından sorumlu değiliz.

## 10. Reklamcılık

Ücretsiz katman kullanıcıları, **Google AdMob** üzerinden sunulan reklamları görebilir. Ücretsiz sürümü kullanarak reklam gösterimine onay vermiş olursunuz. **Pro aboneleri reklamsız deneyim** alır.

## 11. Garanti Reddi

UYGULAMA, AÇIK VEYA ZIMNİ HİÇBİR GARANTİ OLMAKSIZIN **"OLDUĞU GİBİ"** VE **"MEVCUT OLDUĞU ŞEKİLDE"** SUNULMAKTADIR. TİCARİ ELVERİŞLİLİK, BELİRLİ BİR AMACA UYGUNLUK, HAK İHLALİ YOKLUĞU VEYA BİTKİ TANIMLAMA DOĞRULUĞU GARANTİLERİ DÂHİL OLMAK ÜZERE HİÇBİR GARANTİ VERMEYİZ. UYGULAMANIN KESİNTİSİZ, HATASIZ VEYA ZARARLI BİLEŞENLERDEN ARINDIRILMIŞ OLDUĞUNU GARANTİ ETMİYORUZ.

## 12. Sorumluluğun Sınırlandırılması

YASALARIN İZİN VERDİĞİ AZAMİ ÖLÇÜDE, **RESUL SARI**, UYGULAMAYI KULLANIMINIZDAN KAYNAKLANAN DOLAYLI, ARIZÎ, ÖZEL, SONUÇSAL VEYA CEZAİ ZARARLARDAN VEYA HERHANGİ BİR KÂR, VERİ YA DA İTİBAR KAYBINDAN SORUMLU OLMAYACAKTIR. TOPLAM SORUMLULUĞUMUZ, **TALEBİN ORTAYA ÇIKMASINDAN ÖNCEKİ 12 AY İÇİNDE UYGULAMA İÇİN ÖDEDİĞİNİZ TUTARI VEYA 50 USD'Yİ** (HANGİSİ DAHA YÜKSEKSE) AŞMAYACAKTIR.

## 13. Tazminat

Bu Koşulları ihlal etmenizden veya Uygulamayı yanlış kullanmanızdan kaynaklanan tüm taleplere, zararlara veya masraflara karşı **Resul Sarı'yı tazmin etmeyi ve zarara uğratmamayı** kabul edersiniz.

## 14. Sona Erme

Bu Koşulları ihlal etmeniz hâlinde Uygulamaya erişiminizi önceden bildirim yapmaksızın derhâl sonlandırabilir veya askıya alabiliriz. Sona erme üzerine size verilen tüm haklar düşer; ancak **8., 11., 12., 13. ve 17. maddeler yürürlükte kalır**.

Hesabınızı istediğiniz zaman **diova@diova.app** adresine yazarak sonlandırabilirsiniz. Sona erme, peşin ödenmiş tutarların iadesi hakkını doğurmaz.

## 15. Koşulların Değişmesi

Bu Koşullar zaman zaman güncellenebilir. Önemli değişiklikleri Uygulama içi bildirim veya e-posta yoluyla size duyururuz. Değişiklikler yürürlüğe girdikten sonra Uygulamayı kullanmaya devam etmeniz, **kabul anlamına gelir**. Üst kısımdaki "Son güncelleme" tarihi en güncel revizyonu yansıtır.

## 16. Apple'a Özgü Hükümler (iOS Kullanıcıları için)

Bu Koşullar sizinle Resul Sarı arasındadır; **Apple Inc. taraf değildir**. Apple, Uygulamadan veya içeriğinden sorumlu değildir. Yürürlükteki garantilere uyumsuzluk olması durumunda Apple'a bildirimde bulunabilirsiniz; Apple, Uygulamanın satın alma fiyatını iade edecektir. **Apple'ın başka bir garanti yükümlülüğü yoktur**. Apple, bu Koşulların **üçüncü taraf yararlanıcısıdır** ve bu Koşulları size karşı uygulayabilir.

## 17. Uygulanacak Hukuk ve Uyuşmazlıklar

Bu Koşullar, **Türkiye Cumhuriyeti yasalarına** tabidir. Bu Koşullardan doğan tüm uyuşmazlıklarda **İstanbul Çağlayan Mahkemeleri ve İcra Daireleri** yetkilidir. Avrupa Birliği'nde ikamet eden tüketici iseniz, ikamet ettiğiniz ülkenin mahkemelerine de başvurabilirsiniz; ülkenizin **emredici tüketici koruma hükümleri** saklıdır. **6502 sayılı Tüketicinin Korunması Hakkında Kanun** uyarınca tüketici hakem heyetlerine ve tüketici mahkemelerine başvurma hakkınız mahfuzdur.

## 18. İletişim

Bu Koşullar hakkında sorularınız için bize ulaşın:

**Resul Sarı**
E-posta: **diova@diova.app**
Adres talep üzerine paylaşılır.

---

*Chloris'i kullanarak bu Kullanım Koşullarını okuduğunuzu, anladığınızı ve kabul ettiğinizi beyan edersiniz.*
