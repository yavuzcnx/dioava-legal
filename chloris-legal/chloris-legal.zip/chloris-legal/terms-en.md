# Terms of Use

**Last updated:** 7 May 2026
**Effective date:** 7 May 2026

These Terms of Use ("Terms") govern your access to and use of the **Chloris: Plant Scan & Garden** mobile application (the "App") provided by **Resul Sarı**, a sole proprietor trading as **Diova**, registered in Türkiye ("we", "us", "our"). By downloading, installing, or using the App, you ("User", "you") agree to be bound by these Terms. If you do not agree, do not use the App.

---

## 1. Acceptance of the Terms

By creating an account or using the App, you confirm that you are at least 13 years of age (or the minimum age required in your country to consent to data processing) and have the legal capacity to enter into a binding agreement. If you are using the App on behalf of an entity, you represent that you have authority to bind that entity to these Terms.

## 2. License Grant

Subject to your compliance with these Terms, we grant you a limited, non-exclusive, non-transferable, revocable license to download and use the App on a device you own or control, solely for personal, non-commercial purposes. This license is granted by Apple Inc. (for iOS users) and Google LLC (for Android users) under the terms of the Apple Media Services Terms / Google Play Terms of Service, as applicable.

## 3. Subscriptions and In-App Purchases

### 3.1. Available Plans

The App offers the following premium plans:

- **Chloris Pro Monthly** — auto-renewing subscription, billed monthly
- **Chloris Pro Yearly** — auto-renewing subscription, billed annually
- **Chloris Pro Lifetime** — one-time purchase, lifetime access

Prices are displayed within the App at the time of purchase, in your local currency where supported.

### 3.2. Auto-Renewal

Auto-renewing subscriptions automatically renew at the end of each billing period unless cancelled at least 24 hours before the end of the current period. Your payment method will be charged the renewal price within 24 hours prior to the end of the current period. You can manage and cancel subscriptions at any time through your **App Store** account settings (iOS) or **Google Play** account settings (Android). Cancellation takes effect at the end of the current billing period — no partial refunds are provided for unused portions.

### 3.3. Free Trial (where applicable)

If a free trial is offered, it converts automatically to a paid subscription at the end of the trial period unless cancelled at least 24 hours before the trial ends. Only one free trial per Apple ID or Google account is permitted.

### 3.4. Refunds

All purchases are processed by Apple or Google and are subject to their respective refund policies:

- **iOS / App Store:** [https://support.apple.com/en-us/HT204084](https://support.apple.com/en-us/HT204084)
- **Android / Google Play:** [https://support.google.com/googleplay/answer/2479637](https://support.google.com/googleplay/answer/2479637)

We do not process refunds directly. Lifetime purchases are non-refundable except where required by applicable law.

### 3.5. Restoration of Purchases

You can restore previously purchased subscriptions or lifetime access by tapping **"Restore Purchases"** within the App, provided you are signed in with the same Apple ID or Google account used for the original purchase.

## 4. User Account

To access certain features, you must register an account using a valid email address. You are responsible for:

- Keeping your login credentials confidential
- All activity that occurs under your account
- Promptly notifying us of any unauthorised access at **diova@diova.app**

We reserve the right to suspend or terminate accounts that violate these Terms.

## 5. Acceptable Use

You agree NOT to:

- Reverse engineer, decompile, or disassemble the App
- Use the App for any unlawful purpose or in violation of any applicable law
- Upload content that is offensive, infringing, or harmful
- Attempt to bypass any security or subscription mechanism
- Use automated systems (bots, scrapers) to access the App
- Resell, sublicense, or commercially exploit the App or its content

Violation may result in immediate account termination without refund.

## 6. User-Generated Content

If you upload plant photos, notes, or other content to your collection ("User Content"), you retain ownership of that content. By uploading, you grant us a worldwide, royalty-free, non-exclusive licence to store, display, and process that content solely to provide the Service. We do not claim ownership of your User Content and will not use it for marketing without your explicit consent.

## 7. Plant Identification — No Guarantees

The App uses artificial intelligence to identify plants from photos. **Identifications are estimations and may be inaccurate.** Do NOT rely on the App for:

- Identification of toxic, poisonous, or edible plants
- Medical, agricultural, or horticultural decisions involving health or safety
- Legal classification of protected or endangered species

Always consult a qualified expert before consuming, handling, or treating any plant based on App identifications. We are not liable for any harm resulting from reliance on identifications.

## 8. Intellectual Property

The App, including its design, code, graphics, text, and trademarks (collectively, the "Materials"), is owned by Resul Sarı or its licensors and is protected by copyright and other intellectual property laws. No rights are granted to you other than the limited licence in Section 2.

## 9. Third-Party Services

The App integrates third-party services, including:

- **Apple App Store / Google Play** — payment processing
- **Supabase** — authentication and data storage
- **AdMob (Google)** — advertising for free-tier users
- **AI plant identification services** — image analysis

Use of third-party services is governed by their own terms. We are not responsible for the practices of third parties.

## 10. Advertising

Free-tier users may see advertisements served via Google AdMob. By using the free version, you consent to the display of ads. Pro subscribers receive an ad-free experience.

## 11. Disclaimer of Warranties

THE APP IS PROVIDED **"AS IS"** AND **"AS AVAILABLE"**, WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, OR ACCURACY OF PLANT IDENTIFICATION. WE DO NOT WARRANT THAT THE APP WILL BE UNINTERRUPTED, ERROR-FREE, OR FREE OF HARMFUL COMPONENTS.

## 12. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, RESUL SARI SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS, DATA, OR GOODWILL, ARISING FROM YOUR USE OF THE APP. OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNT YOU PAID FOR THE APP IN THE 12 MONTHS PRECEDING THE CLAIM, OR USD 50, WHICHEVER IS GREATER.

## 13. Indemnification

You agree to indemnify and hold harmless Resul Sarı from any claims, damages, or expenses arising from your violation of these Terms or your misuse of the App.

## 14. Termination

We may terminate or suspend your access to the App immediately, without prior notice, if you breach these Terms. Upon termination, all rights granted to you cease, but Sections 8, 11, 12, 13, and 17 survive.

You may terminate your account at any time by contacting **diova@diova.app**. Termination does not entitle you to a refund of any prepaid amounts.

## 15. Changes to the Terms

We may update these Terms from time to time. We will notify you of material changes via in-app notice or email. Continued use after changes take effect constitutes acceptance. The "Last updated" date at the top reflects the latest revision.

## 16. Apple-Specific Terms (for iOS Users)

These Terms are between you and Resul Sarı, not Apple Inc. Apple is not responsible for the App or its content. In the event of any failure to conform to applicable warranties, you may notify Apple, and Apple will refund the purchase price of the App. Apple has no other warranty obligation. Apple is a third-party beneficiary of these Terms and may enforce them against you.

## 17. Governing Law and Disputes

These Terms are governed by the laws of the **Republic of Türkiye**, without regard to conflict of law principles. Any dispute arising out of these Terms shall be resolved in the **Istanbul Çağlayan Courts**, Türkiye. If you are a consumer residing in the European Union, you may also bring claims in the courts of your country of residence; mandatory consumer protection laws of your country apply.

## 18. Contact

For questions about these Terms, contact us at:

**Resul Sarı**
Email: **diova@diova.app**
Address available upon request.

---

*By using Chloris, you acknowledge that you have read, understood, and agree to these Terms of Use.*
