# Gizlilik Politikası

**Son güncelleme:** 7 Mayıs 2026
**Yürürlük tarihi:** 7 Mayıs 2026

Bu Gizlilik Politikası; Türkiye'de mukim şahıs şirketi **Resul Sarı** ("biz", "tarafımız") tarafından sunulan **Chloris: Plant Scan & Garden** mobil uygulamasını ("Uygulama") kullandığınızda kişisel verilerinizi nasıl topladığımızı, kullandığımızı ve koruduğumuzu açıklar. Uygulamayı kullanarak aşağıda açıklanan uygulamaları kabul etmiş olursunuz.

**Resul Sarı**, AB Genel Veri Koruma Yönetmeliği (GDPR) kapsamında **veri sorumlusu** ve 6698 sayılı **Kişisel Verilerin Korunması Kanunu (KVKK)** kapsamında **veri sorumlusu** sıfatıyla hareket etmektedir.

Bu metin, **KVKK Madde 10** kapsamındaki **aydınlatma yükümlülüğümüzün** yerine getirilmesi amacını da taşır.

---

## 1. Topladığımız Bilgiler

Uygulamayı çalıştırmak için **yalnızca gerekli** verileri topluyoruz. Aşağıdaki kategoriler işlediğimiz verilerin tamamını kapsar; bunlar dışında veri toplamıyoruz.

### 1.1. Hesap Bilgileri

Kayıt olduğunuzda topladığımız bilgiler:

- **E-posta adresi** — hesap oluşturma, kimlik doğrulama ve hizmet iletişimi için
- **Parola** — yalnızca tuzlu hash olarak saklanır; düz metin olarak görmüyor veya saklamıyoruz
- **Kullanıcı Kimliği (User ID)** — kimlik doğrulama sağlayıcımız (Supabase) tarafından oluşturulan benzersiz tanımlayıcı

### 1.2. Kamera ve Fotoğraf Galerisi Erişimi

Uygulama, bitki tarayabilmeniz için **kamera** ve **fotoğraf galerisi** izni ister. Taradığınız fotoğraflar:

- Analiz için yapay zekâ bitki tanımlama servisimize gönderilir
- İsteğe bağlı olarak kişisel Plantdex koleksiyonunuza kaydedilir
- Cihazlar arası senkronizasyon için hesabınıza bağlanır

Cihaz ayarlarınızdan kamera veya fotoğraf izinlerini istediğiniz zaman geri alabilirsiniz. **Açıkça taramayı seçmediğiniz hiçbir fotoğrafı taramayız veya yüklemeyiz.**

### 1.3. Bitki Tarama Verileri

Bir bitki taradığınızda işlediğimiz veriler:

- Bitki fotoğrafı
- Tanımlama sonucu (tür adı, güven skoru)
- Zaman damgası ve yaklaşık tarama sayısı (kullanım limitleri için)

Bu veriler hesabınıza kaydedilir ve kişisel Plantdex koleksiyonunuzu beslemek için kullanılır.

### 1.4. Abonelik ve Satın Alma Verileri

Bir abonelik veya tek seferlik ürün satın aldığınızda:

- Satın alma onayı, işlem kimliği ve yetkilendirme durumu **Apple App Store** veya **Google Play** tarafından işlenir ve abonelik yönetim sağlayıcımız (RevenueCat) ile paylaşılır
- **Tam kart numaranızı, banka bilgilerinizi veya fatura adresinizi GÖRMÜYORUZ** — yalnızca yetkilendirme durumu (Pro / Ücretsiz) bize ulaşır

### 1.5. Reklamcılık Verileri (Yalnızca Ücretsiz Sürüm)

Uygulamanın ücretsiz sürümünü kullanıyorsanız, **Google AdMob** Uygulama içinde reklam sunabilir. AdMob şu verileri toplayabilir:

- **Reklam tanımlayıcısı** (iOS'ta IDFA, Android'de AAID) — iOS'ta yalnızca App Tracking Transparency üzerinden onayınızla
- **Yaklaşık cihaz konumu** (şehir düzeyinde) — alakalı reklam sunmak için
- **Cihaz tipi, OS sürümü ve reklam etkileşim verileri**

Cihaz ayarlarınızdan veya iOS'taki App Tracking Transparency aracılığıyla **kişiselleştirilmiş reklamlardan vazgeçebilirsiniz**. **Pro aboneleri reklam görmez** ve AdMob tarafından reklam verisi toplanmaz.

### 1.6. Teknik Bilgiler

Uygulamayı çalıştırmak için otomatik olarak topladığımız temel teknik veriler:

- Cihaz modeli ve OS sürümü
- Uygulama sürümü ve çökme kayıtları (hataları gidermek için)
- IP adresi (güvenlik, dolandırıcılık önleme ve bölgesel fiyatlandırma için)

Rehberinizi, takviminizi, mikrofonunuzu, hassas konumunuzu, tarama geçmişinizi veya **burada listelenenler dışında hiçbir veriyi TOPLAMIYORUZ**.

---

## 2. Bilgilerinizi Nasıl Kullanırız

Verilerinizi yalnızca aşağıda listelenen amaçlar için kullanıyoruz:

| Amaç | Hukuki Sebep (KVKK / GDPR) | Kullanılan Veri |
|------|---------------------------|-----------------|
| Uygulamayı sağlamak ve işletmek | Sözleşmenin ifası | E-posta, fotoğraflar, tarama verileri |
| Hesabınızın kimliğini doğrulamak | Sözleşmenin ifası | E-posta, parola hash, kullanıcı kimliği |
| Fotoğraflardan bitki tanımlamak | Sözleşmenin ifası | Bitki fotoğrafları |
| Cihazlar arası senkronizasyon | Sözleşmenin ifası | Tarama verileri, kullanıcı kimliği |
| Abonelik işlemleri | Sözleşmenin ifası | Apple/Google'dan satın alma verileri |
| Reklam sunmak (ücretsiz katman) | **Açık rıza** | Reklam tanımlayıcıları, etkileşim |
| Hata giderme ve istikrar | Meşru menfaat | Çökme kayıtları, teknik veri |
| Dolandırıcılığı önlemek | Meşru menfaat | IP adresi, teknik veri |
| Yasal yükümlülükler | Yasal yükümlülük | Gerektiği kadar tüm kategoriler |

**Kişisel verilerinizi SATMIYORUZ**, bağlamsal davranışsal reklamcılık için paylaşmıyoruz veya **onayınız olmadan** yapay zekâ modellerini eğitmek için kullanmıyoruz.

---

## 3. Bilgilerinizi Nasıl Paylaşırız

Verileri yalnızca aşağıdaki hizmet sağlayıcılarla, listelenen amaçlar dâhilinde paylaşıyoruz:

### 3.1. Hizmet Sağlayıcıları

| Sağlayıcı | Amaç | Paylaşılan Veri | Konum |
|-----------|------|-----------------|-------|
| **Supabase, Inc.** | Kimlik doğrulama, veritabanı | E-posta, parola hash, tarama verileri | ABD / AB |
| **RevenueCat, Inc.** | Abonelik yönetimi | Satın alma kimlikleri, yetkilendirme | ABD |
| **Google AdMob** | Reklamcılık (ücretsiz sürüm) | Reklam kimliği, etkileşimler | ABD |
| **Bitki Tanıma AI Sağlayıcısı** | Bitki tanımlama | Bitki fotoğrafları (hesap bilgisi yok) | ABD / AB |
| **Apple App Store** | iOS ödeme | Satın alma verileri | ABD |
| **Google Play** | Android ödeme | Satın alma verileri | ABD |

### 3.2. Yasal Açıklamalar

Yürürlükteki yasalar, mahkeme kararı veya devlet talebi gerektiriyorsa veya kullanıcıların ya da kamunun haklarını, güvenliğini veya mülkiyetini korumak için gerekli olduğunda verilerinizi açıklayabiliriz.

### 3.3. İş Devirleri

Resul Sarı başka bir şirket tarafından satın alınır veya birleşirse, verileriniz halef tüzel kişiliğe devredilebilir. **Devirden önce sizi bilgilendireceğiz** ve hesabınızı silme seçeneği sunacağız.

**Kişisel verilerinizi hiçbir amaçla üçüncü taraflara SATMIYORUZ.**

---

## 4. Uluslararası Veri Aktarımları

Verileriniz, hizmet sağlayıcılarımızın bulunduğu **Amerika Birleşik Devletleri** ve **Avrupa Birliği** dâhil olmak üzere Türkiye dışındaki ülkelerde işlenebilir. Türkiye / AAB dışına aktarımlarda şu mekanizmalara dayanırız:

- Avrupa Komisyonu tarafından onaylanan **Standart Sözleşme Hükümleri (SCC)**
- Hizmet sağlayıcıların **AB-ABD Veri Gizliliği Çerçevesi** gibi düzenlemelere uyumluluğu
- KVKK'ya uygun aktarım mekanizmaları (**KVKK Madde 9** kapsamında açık rıza veya taahhütler)

---

## 5. Veri Saklama

Verilerinizi yalnızca gerektiği kadar saklıyoruz:

- **Hesap verileri:** hesabınızı silinceye kadar
- **Bitki taramaları / koleksiyon:** siz silene veya hesabınızı kapatıncaya kadar
- **Çökme kayıtları:** 90 gün
- **Reklamcılık verileri:** Google'ın politikası uyarınca AdMob tarafından saklanır
- **Satın alma kayıtları:** vergi mevzuatı gereği (Türkiye'de **10 yıl**)

Hesabınızı sildiğinizde, kişisel verilerinizi **30 gün içinde** silinir veya anonimleştiririz; ancak yasal saklama yükümlülükleri saklıdır.

---

## 6. Haklarınız

Kişisel verilerinizle ilgili olarak aşağıdaki haklara sahipsiniz:

### 6.1. KVKK Madde 11 Kapsamında (Türkiye Kullanıcıları)

KVKK Madde 11 uyarınca **veri sahibi** olarak:

- Kişisel verilerinizin **işlenip işlenmediğini öğrenme**
- İşlenen kişisel verileriniz hakkında **bilgi talep etme**
- İşlenme **amacını** ve amacına uygun kullanılıp kullanılmadığını öğrenme
- Yurt içinde / yurt dışında **aktarıldığı kişileri bilme**
- Eksik veya yanlış işlenmişse **düzeltilmesini isteme**
- KVKK 7. madde kapsamında **silinmesini veya yok edilmesini** isteme
- Düzeltme/silme işlemlerinin aktarıldığı üçüncü kişilere **bildirilmesini isteme**
- Otomatik sistemlerle yapılan analiz sonucunda aleyhinize çıkan sonuca **itiraz etme**
- Hukuka aykırı işleme nedeniyle **zarara uğramanız hâlinde tazminat talep etme**

### 6.2. GDPR Kapsamında (AB / AAB Kullanıcıları)

- **Erişim hakkı** — verilerinizin bir kopyasını talep etme
- **Düzeltme hakkı** — yanlış verileri düzelttirme
- **Silme hakkı ("unutulma hakkı")** — hesabınızı ve verilerinizi sildirme
- **İşlemeyi kısıtlama hakkı**
- **Veri taşınabilirliği hakkı** — verilerinizi makine okunabilir formatta alma
- **İtiraz hakkı** — meşru menfaate dayalı işlemeye itiraz
- **Onayı geri çekme hakkı** — onaya dayalı işlemeler için (örn. reklam)
- Yerel **Veri Koruma Otoritenize şikâyet** etme hakkı

### 6.3. Haklarınızı Nasıl Kullanırsınız

**diova@diova.app** adresine talebinizi iletin. **30 gün içinde** yanıt vereceğiz. Hassas işlemler (örn. veri silme) öncesi kimlik doğrulaması talep edebiliriz.

Hesabınızı doğrudan Uygulamadan da silebilirsiniz: **Ayarlar → Hesap → Hesabı Sil**.

---

## 7. Çocukların Gizliliği

Uygulama, **13 yaşın altındaki çocuklar** (veya bulunduğunuz yargı bölgesinde eşdeğer asgari yaş) için tasarlanmamıştır. Bu yaşın altındaki çocuklardan bilerek veri toplamayız. Bir çocuğun bize kişisel veri sağladığını düşünüyorsanız **diova@diova.app** ile iletişime geçin, veriyi sileceğiz.

13–17 yaş arası kullanıcılar için abonelik özelliklerini kullanmadan önce **veli onayı alınmasını öneririz**.

---

## 8. Güvenlik

Verilerinizi korumak için sektör standardı güvenlik önlemleri uygularız:

- Tüm ağ iletişimi için **iletim sırasında şifreleme** (TLS 1.2+)
- Saklanan veriler için **dinlenme hâlinde şifreleme** (AES-256)
- **Hash'lenmiş parolalar** (bcrypt veya eşdeğer) — düz parolanızı asla görmeyiz
- **Erişim kontrolleri** — yalnızca yetkili personel kullanıcı verilerine erişebilir
- Altyapımızın **düzenli güvenlik incelemeleri**

Hiçbir sistem %100 güvenli değildir. Kişisel verilerinizi etkileyen bir veri ihlali durumunda, GDPR / KVKK gerekliliklerine uygun olarak sizi ve ilgili Veri Koruma Otoritesini **72 saat içinde** bilgilendireceğiz.

---

## 9. Çerezler ve Benzer Teknolojiler

Uygulamanın kendisi tarayıcı çerezi kullanmaz. Ancak reklam ortağımız (AdMob), reklam sunumu için **cihaz tanımlayıcılarını** kullanabilir. Web sitemiz (varsa) temel analitik için çerezler kullanabilir — web sitesinin ayrı çerez bildirimine bakınız.

---

## 10. Bu Gizlilik Politikasındaki Değişiklikler

Bu Gizlilik Politikasını zaman zaman güncelleyebiliriz. Önemli değişiklikler, yürürlüğe girmeden **en az 30 gün önce** Uygulama içi bildirim veya e-posta yoluyla iletilir. Üst kısımdaki "Son güncelleme" tarihi en son revizyonu yansıtır. Değişiklikler yürürlüğe girdikten sonra Uygulamayı kullanmaya devam etmeniz, **kabul anlamına gelir**.

---

## 11. İletişim ve Veri Koruma Talepleri

Gizlilik ile ilgili sorular, talepler veya şikâyetler için:

**Veri Sorumlusu / Data Controller:**
**Resul Sarı**, **Diova** ticari adıyla faaliyet gösteren şahıs şirketi (Türkiye)
E-posta: **diova@diova.app**

**AB / AAB kullanıcıları:** Yerel Veri Koruma Otoritenize şikâyette bulunma hakkınız mahfuzdur.

**Türkiye kullanıcıları:** Kişisel Verileri Koruma Kurumu'na ([www.kvkk.gov.tr](https://www.kvkk.gov.tr)) şikâyette bulunma hakkınız mahfuzdur.

---

*Gizliliğiniz bizim için önemli. Bu politikada anlaşılmayan bir şey varsa, bize yazın — sade dille açıklayalım.*
